from django.apps import AppConfig


class LoginscreenConfig(AppConfig):
    name = 'loginscreen'
