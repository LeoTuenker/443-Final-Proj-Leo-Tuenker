from django.contrib import admin
from student.models import StudentDetails
from student.models import CourseDetails
from import_export.admin import ImportExportModelAdmin
from import_export import resources

# Register your models here.
admin.site.register(StudentDetails)

admin.site.register(CourseDetails)
