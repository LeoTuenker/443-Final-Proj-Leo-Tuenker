from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from student.models import StudentDetails, CourseDetails
from django.db import connection
from django.core.paginator import Paginator


def dictfetchall(cursor):
    "Return all rows from a cursor as a dict"
    columns = [col[0] for col in cursor.description]
    return [
        dict(zip(columns, row))
        for row in cursor.fetchall()
    ]
# Create your views here.
@login_required
def home(request):

    cursor = connection.cursor()
    cursor.execute("SELECT COUNT(*) 'totalstudents' FROM student_studentdetails")
    totaldata = dictfetchall(cursor)

    cursor.execute("SELECT COUNT(*) 'totalseniors' FROM student_studentdetails WHERE year='Senior' ")
    seniordata = dictfetchall(cursor)

    cursor.execute("SELECT COUNT(*) 'totaljuniors' FROM student_studentdetails WHERE year='Junior' ")
    juniordata = dictfetchall(cursor)

    cursor.execute("SELECT COUNT(*) 'totalfreshman' FROM student_studentdetails WHERE year='Freshman' ")
    freshmandata = dictfetchall(cursor)

    cursor.execute("SELECT COUNT(*) 'coursecount' FROM student_coursedetails")
    coursedata = dictfetchall(cursor)

    cursor.execute("SELECT AVG(GPA) 'averagegpa' FROM student_studentdetails")
    gpadata = dictfetchall(cursor)

    return render(request, 'student/home.html', {'totaldata' : totaldata, 'seniordata' : seniordata, 'juniordata' : juniordata, 'freshmandata' : freshmandata, 'coursedata' : coursedata, 'gpadata' : gpadata})


@login_required
def studentdetails(request):
    #studentdata = StudentDetails.objects.all()
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM student_studentdetails")
    studentdata =  dictfetchall(cursor)

    paginator = Paginator(studentdata, 10)
    page = request.GET.get('page')
    studentminiset = paginator.get_page(page)
    return render(request, 'student/studentdetails.html', {'data' : studentminiset})

@login_required
def coursedetails(request):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM student_coursedetails")
    coursedata =  dictfetchall(cursor)

    paginator = Paginator(coursedata, 10)
    page = request.GET.get('page')
    courseminiset = paginator.get_page(page)

    return render(request, 'student/coursedetails.html', {'data': courseminiset})

@login_required
def courseenrollment(request):

    cursor = connection.cursor()
    cursor.execute("SELECT firstname, lastname 'name' FROM student_studentdetails")
    studentdata =  dictfetchall(cursor)


    #commneted out because I wasn't able to get it right but had some progress, also why I didn't include 'enrollmentdata' : enrollmentdata below
    #cursor.execute("SELECT coursename FROM student_enrollmentdetails WHERE studentID IS %s")
    enrollmentdata = dictfetchall(cursor)

    return render(request, 'student/courseenrollment.html', {'studentdata' : studentdata})
