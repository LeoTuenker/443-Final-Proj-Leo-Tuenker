from django.db import models

# Create your models here.
class StudentDetails(models.Model):
    studentID = models.IntegerField(default=1000)
    firstname = models.CharField(max_length=500)
    lastname = models.CharField(max_length=500)
    major = models.CharField(max_length=500)
    year = models.CharField(max_length=50)
    GPA = models.DecimalField(max_digits=6, decimal_places=3)

class CourseDetails(models.Model):
    courseID = models.IntegerField()
    coursetitle = models.CharField(max_length=500, default="class")
    coursename = models.CharField(max_length=500)
    coursesectioncode = models.IntegerField(default="1")
    coursedept = models.CharField(max_length=500, default="college")
    courseinstructor = models.CharField(max_length=500, default="professor")

class EnrollmentDetails (models.Model):
    studentID = models.IntegerField(default=1000)
    coursename = models.CharField(max_length=500, default="class")
